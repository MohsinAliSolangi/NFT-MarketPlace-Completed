// import React,{ useState } from "react"
// import { Button, Modal, ModalHeader } from "reactstrap"


// export function PriceModal(props){ 
   
//     const [modal, setmodal]= useState(false)

//     const prop= setmodal(props.true)                                                                   
//     return(
//     <div>
//     <Modal
//     size='lg'
//     isOpen={modal}
//     toggle={() => setmodal(!modal)}>
    
//     <ModalHeader
//         toggle={() => setmodal(!modal)}>
    
//             PopUp
//         </ModalHeader>
//     </Modal>
//     <div>
//     <Button > this is </Button>


//     </div>

//     </div>
    
//     )
//     }
